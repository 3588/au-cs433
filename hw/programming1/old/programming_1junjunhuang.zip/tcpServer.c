/*code for example echo server program that uses TCP */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#define PORTNUMBER      6000            /* default protocol port number */
#define BSIZE           1000            /* size of data buffer          */

#define  MAXLINE    1000

/*------------------------------------------------------------------------
 * Program:   tcp echo server
 *
 * Purpose:   allocate a socket and then repeatedly execute the following:
 *              (1) wait for the next connection from a client
 *              (2) loop:
 *                      read data from the socket
 *                      write the data back to the socket
 *                  until the connection is closed by the client
 *              (3) go back to step (1)
 *
 * Syntax:    tcpServer
 *
 * You can follow the hints below to finish the code step by step.
 *------------------------------------------------------------------------
 */

main(int argc, char**argv) 
{ 
	

struct  sockaddr_in sad; /* structure to hold server's address  */
  struct  sockaddr_in cad; /* structure to hold client's address  */
  int     sd, sd2;         /* socket descriptors                  */
//  int     alen;            /* length of address                   */
//  int     bytect;          /* byte count for the current client   */
//  int     n;               /* byte count for the current request  */
 // char    buf[BSIZE];      /* buffer for string the server sends  */
  struct hostent *hptr;
socklen_t  addrlen; 

                 
  
 
 
 /* Set up address for local socket */
	memset((char *)&sad,0,sizeof(sad)); /* clear sockaddr structure */
	sad.sin_family = AF_INET;           /* set family to Internet     */
	sad.sin_addr.s_addr = INADDR_ANY;   /* set the local IP address   */
	sad.sin_port = htons((u_short)PORTNUMBER);/* convert to network byte order */
	
	/* Create a socket */
	//int socket(int domain, int type, int protocol);
 sd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (sd < 0) {
        perror("socket creation");
        exit(1);
        }


 
 /* Bind a local address to the socket */
	//int bind(int sockfd, struct sockaddr *my_addr, socklen_t addrlen);
	if (bind(sd, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
        perror("bind");
        exit(1);
	}
 
    if(listen(sd,BSIZE)==-1) 
    { 
        perror("listen error!"); 
         exit(1); 
    } 
 
 
    addrlen=sizeof(struct sockaddr_in); 
        sd2=accept(sd,(struct sockaddr *)&cad,&addrlen); 
 
    while(1) 
    { 
  
        

			         /*  Display a message showing the client's address */
                printf("%d bytes received from ", sd2);
                if((hptr = gethostbyaddr((char*)&cad.sin_addr, sizeof(struct sockaddr_in),AF_INET))==0){
                        printf("%s port %d\n", inet_ntoa(cad.sin_addr),ntohs(cad.sin_port));
                }
                else {
                        printf("%s/%s port %d\n", hptr->h_name,inet_ntoa(cad.sin_addr),ntohs(cad.sin_port));
                }
                
                 /*  Send it back to the client */
                 char *recvm[32]; 
                 int byss, len, bytesrecv;
                 bytesrecv= recv(sd2,recvm, len, 0);
                 len=strlen(recvm);
                byss=send(sd2,recvm, len, 0);
         printf("Send message %s Byte %d ",recvm,byss);
         shutdown(sd2, 2);
          sd2=accept(sd,(struct sockaddr *)&cad,&addrlen); 
             
       
}
			 
       
            ;
      } 
   

